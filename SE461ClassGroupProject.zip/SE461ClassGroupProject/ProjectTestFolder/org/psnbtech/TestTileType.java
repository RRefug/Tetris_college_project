package org.psnbtech;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TestTileType {

	//private TileType tile;
	
//	@Before
//	void setUp() throws Exception {
////		tile = TileType.TypeI;
////		testTileType = TileType.TypeJ;
//	}
//
//	@After
//	void tearDown() throws Exception {
////		tile = null;
//	}

//	@Test
//	public void testGetBaseColor() {
////		tile = TileType.TypeI;
//		
//		try {
//			Color color = new Color(BoardPanel.COLOR_MIN, BoardPanel.COLOR_MAX, BoardPanel.COLOR_MAX);
//			assertEquals(color, tile.getBaseColor());
//		}catch(Exception e) {
//			fail("Not base color");
//		}
//	}
//	
//	@Test
//	public void testGetLightColor() {
//		tile = TileType.TypeJ;
//		try {
//			Color light = new Color(BoardPanel.COLOR_MIN, BoardPanel.COLOR_MIN, BoardPanel.COLOR_MAX);
//			light = light.brighter();
//			assertEquals(light, tile.getLightColor());
//		}catch(Exception e) {
//			fail("Not light color");
//		}
//	}
//	
//	@Test
//	public void testGetDarkColor() {
//		tile = TileType.TypeS;
//		try {
//			Color dark = new Color(BoardPanel.COLOR_MIN, BoardPanel.COLOR_MAX, BoardPanel.COLOR_MIN);
//			dark = dark.darker();
//			
//			assertEquals(dark, tile.getDarkColor());
//		} catch(Exception e) {
//			fail("Not dark color");
//		}
//	}
////	
//	@Test
//	public void testGetDimension() {
//		tile = TileType.TypeS;
//		try {
//			assertEquals(3, tile.getDimension());
//		}catch(Exception e) {
//			
//		}
//	}
//	
//	@Test
//	public void testGetSpawnColumn() {
//		tile = TileType.TypeS;
//		try {
//			assertEquals(4, tile.getSpawnColumn());
//		}catch(Exception e) {
//			fail("Not a column");
//		}
//		
//	}
//	
//	@Test
//	public void testGetSpawnRow() {
//		tile = TileType.TypeS;
//		try {
//			assertEquals(4, tile.getSpawnRow());
//		}catch(Exception e) {
//			fail("Not a row");
//		}	
//	}
//	
//	@Test
//	public void testGetRows() {
//		tile = TileType.TypeS;
//		try {
//			assertEquals(2, tile.getRows());
//		}catch(Exception e) {
//			fail("Exception caught");
//		}
//	}
//	
//	@Test
//	public void testGetColumns() {
//		tile = TileType.TypeS;
//		try {
//			assertEquals(3, tile.getCols());
//		}catch(Exception e) {
//			fail("Exception caught");
//		}
//		tile = TileType.TypeZ;
//		try {
//			assertEquals(3, tile.getCols());
//		}catch(Exception e) {
//			fail("Exception caught");
//		}
//	}
//	
//	@Test
//	public void testIsTile() {
//		tile = TileType.TypeI;
//		
//		assertFalse(tile.isTile(0, 0, 0)); 
//		assertFalse(tile.isTile(1, 0, 0));
//		assertFalse(tile.isTile(2, 0, 0));
//		assertFalse(tile.isTile(3, 0, 0));
//		
//		assertTrue(tile.isTile(0, 1, 0)); 
//		assertTrue(tile.isTile(0, 1, 0));
//		assertTrue(tile.isTile(0, 1, 0));
//		assertTrue(tile.isTile(0, 1, 0));
//		
//		assertFalse(tile.isTile(0, 0, 0)); 
//		assertFalse(tile.isTile(0, 0, 1));
//		assertFalse(tile.isTile(0, 0, 2));
//		assertFalse(tile.isTile(0, 0, 3));
//		
//		assertFalse(tile.isTile(0, 0, 0)); 
//		assertFalse(tile.isTile(1, 0, 0));
//		assertFalse(tile.isTile(0, 2, 0));
//		assertFalse(tile.isTile(0, 0, 3));
//	}
//	
//	@Test
//	public void testGetLeftInset() {
//		//testing values 0-3 for tile type I, passing values 0-3 because max length is 3
//		tile = TileType.TypeI;
//		
//		assertEquals(1, tile.getLeftInset(3));
//		assertEquals(0, tile.getLeftInset(2));
//		assertEquals(2, tile.getLeftInset(1));
//		assertEquals(0, tile.getLeftInset(0));
//	
//	}
//	
//	@Test
//	public void testGetRightInset() {
//		//testing values for tile type J
//		
//		tile = TileType.TypeJ; 
//		
//		assertEquals(2, tile.getRightInset(3));
//		assertEquals(1, tile.getRightInset(2));
//		assertEquals(1, tile.getRightInset(1));
//		assertEquals(1, tile.getRightInset(0));
//	}
//	
//	
//
//	@Test
//	public void testGetTopInset() {
//		tile = TileType.TypeS; 
//		
//		assertEquals(0, tile.getTopInset(3));
//		assertEquals(1, tile.getTopInset(2));
//		assertEquals(0, tile.getTopInset(1));
//		assertEquals(0, tile.getTopInset(0));
//			
//	}
//
//	@Test
//	public void testGetBottomInset() {
//		tile = TileType.TypeO;
//		
//		assertEquals(1, tile.getBottomInset(3));
//		assertEquals(1, tile.getBottomInset(2));
//		assertEquals(1, tile.getBottomInset(1));
//		assertEquals(1, tile.getBottomInset(0));
//		
//	}
	
//	@Test
//	void test() {
//		
//	}
	
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}

}
