package org.psnbtech;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.awt.Color;
import java.awt.Dimension;
//import java.util.Scanner;
import javax.swing.JFrame;

import org.psnbtech.*;

public class TestBoardPanel {

	private BoardPanel boardPanel;
	//private Tetris tetris;
	
	@Before
	public void setUp() throws Exception {
		boardPanel = new BoardPanel(null);
	}

	@After
	public void tearDown() throws Exception {
		boardPanel = null;
	}

	@Test
	public void testBoardPanel() {
		Dimension d = new Dimension(boardPanel.COL_COUNT, boardPanel.ROW_COUNT);
		
		Tetris tetris = null;
		
		try {
			tetris = new Tetris();
			tetris.isGameOver = true;
			tetris.setVisible(false);
		}catch(java.lang.NullPointerException e) {}
		
		JFrame frame = new JFrame();
		frame.add(boardPanel);
		frame.setFocusable(true);
		frame.setAlwaysOnTop(true);
		frame.setFocusableWindowState(true);
		frame.pack();
		frame.setVisible(true);
		
//		assertEquals(d, boardPanel.getSize());
//		
//		Color color = Color.BLACK;
//		assertEquals(color, boardPanel.getBackground());
//		
//		assertEquals(tetris, boardPanel.tetris);
//		frame.dispose();
//		
//		assertSame(tetris, boardPanel.tetris);
		
	}
	
	@Test
	public void testClear() {
		TileType[][] clearBoard = new TileType[22][10];
//		
		boardPanel.addPiece(TileType.TypeL, 5, 5, 0);
		
//		boardPanel.clear();
//		assertNull(boardPanel.tiles[0][1]);
		
		assertTrue(assertArrayNotEqual(clearBoard, boardPanel.tiles));
		
		boardPanel.clear();
		assertArrayEquals(clearBoard, boardPanel.tiles);
		
		TileType t = TileType.TypeO;
		TileType[][] fullBoard = {
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},

				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},

				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},

				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t},

				{t, t, t, t, t,   t, t, t, t, t},
				{t, t, t, t, t,   t, t, t, t, t}
		};
		
		boardPanel.tiles = fullBoard;
		assertTrue(assertArrayNotEqual(clearBoard, boardPanel.tiles));
		
		boardPanel.clear();
		assertArrayEquals(clearBoard, boardPanel.tiles);
		
	}

	@Ignore
	private boolean assertArrayNotEqual(TileType[][] expected, TileType[][] actual) {
		// TODO Auto-generated method stub
		Boolean notSame = null;
		try {
			assertArrayEquals(expected, actual);
			notSame = false;
		}catch(AssertionError e) {
			notSame = true;
			e.printStackTrace();
		}
		return notSame;
	} 
	
	@Test
	public void testIsValidAndEmpty() {
		boardPanel = new BoardPanel(null);
		
		assertFalse(boardPanel.isValidAndEmpty(TileType.TypeI, 10, 10, 0));
		
		assertFalse(boardPanel.isValidAndEmpty(TileType.TypeI, 2, 21, 1));
		
		assertTrue(boardPanel.isValidAndEmpty(TileType.TypeO, 5, 5, 0));
		
		boardPanel.addPiece(TileType.TypeO, 5, 5, 0);
		
		assertFalse(boardPanel.isValidAndEmpty(TileType.TypeO, 5, 5, 0));
		
		assertFalse(boardPanel.isValidAndEmpty(TileType.TypeS, 3, 5, 0));
		
		assertFalse(boardPanel.isValidAndEmpty(TileType.TypeL, 5, 4, 2));
	}
	
	@Test
	public void testAddPiece() {
		boardPanel = new BoardPanel(null);
		
		TileType O = TileType.TypeO;
		TileType I = TileType.TypeI;
		
		TileType[][] expected = {
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, O,    O, 	null, null, null, null, null},
				{null, null, null, O,    O,     null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{I   , I   , I   , I   , null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null}
		};
		
		boardPanel.addPiece(O, 3, 5, 0);
		boardPanel.addPiece(I, 0, 8, 2);
		assertArrayEquals(expected, boardPanel.tiles);
	}
	
	@Test
	public void testCheckLines() {
		TileType O = TileType.TypeO;
		TileType I = TileType.TypeI;
		TileType S = TileType.TypeS;
		
		TileType[][] expected_4 = {
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{O, I, I, I, I, O, O, I, I, I},
				{O, I, I, I, I, O, O, I, I, I},
				{null, null, null, null, null,  null, null, null, null, null},
				
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{   I,    S,    I,    S,    I,     I,    I,    I, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null,    I,    I,  null, null, null, null, null},

				{O, I, I, I, I, O, O, I, S, I},
				{O, I, S, I, I, O, O, I, I, I},	
		};
		
		TileType[][] expected_1 = {
				{   O,    I,    I,    I,    I,     O,    O,    I,    I,    I},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null,    I,    I, null, null},
				{null, null, null, null,    I,     I, null, null, null, null},
				{null, null, null, null,    I,     I, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null,    I,    I,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},

				{null, null, null, null, null,  null, null, null, null, null},
				{null, null, null, null, null,  null, null, null, null, null},
		};
		
		TileType[][] expected_22 = {
			{O, I, I, I, I,   O, O, I, S, I},
			{O, I, S, I, I,   O, O, I, I, I},
			
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},

			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},

			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},

			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
			{O, I, S, I, I,   O, O, I, I, I},
		};
		
		boardPanel.tiles = expected_22;
		assertEquals(22, boardPanel.checkLines());
		
		boardPanel = new BoardPanel(null);
//		assertEquals(0, boardPanel.checkLines());
//		
//		boardPanel.tiles = expected_4;
//		assertEquals(4, boardPanel.checkLines());
//		
//		boardPanel.tiles = expected_1;
//		assertEquals(1, boardPanel.checkLines());
	}
	
	@Test
	public void testCheckLine() {
		TileType x = TileType.TypeZ;
		int f = 0;
		int m = 14;
		int l = 21;
		
		TileType[][] test_1fe = {		
				{x, x, x, x, x, x, x, x, x, x},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	};
			TileType[][] test_1fa = {		
				{x, x, x, x, x, x, x, x, x, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, x, null, null, x, x, x, x, null},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, null, null, x, x, x, null, null, x, x},	};
			TileType[][] test_1me = {		
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{x, x, x, x, x, x, x, x, x, x},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	};
			TileType[][] test_1ma = {		
				{null, null, x, null, x, x, null, null, null, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, x, x, x, x, x, x, x, x},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, null, null, x, x, x, null, null, x, x},	};
			TileType[][] test_1le = {		
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{x, x, x, x, x, x, x, x, x, x},	};
			TileType[][] test_1la = {		
				{null, null, x, null, x, x, null, null, null, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, x, null, null, x, x, x, x, null},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, x, x, x, x, x, x, x, x, x},	};
			TileType[][] test_0fe = {		
				{x, x, null, null, x, x, x, x, x, x},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	};
			TileType[][] test_0fa = {		
				{x, x, null, null, x, x, x, x, x, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, x, null, null, x, x, x, x, null},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, null, null, x, x, x, null, null, x, x},	};
			TileType[][] test_0me = {		
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{x, x, null, null, x, x, x, x, x, x},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	};
			TileType[][] test_0ma = {		
				{null, null, x, null, x, x, null, null, null, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, null, null, x, x, x, x, x, x},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, null, null, x, x, x, null, null, x, x},	};
			TileType[][] test_0le = {		
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{null, null, null, null, null, null, null, null, null, null},	
				{x, x, null, null, x, x, x, x, x, x},	};
			TileType[][] test_0la = {		
				{null, null, x, null, x, x, null, null, null, x},	
				{null, x, null, null, x, null, null, null, null, null},	
				{null, x, null, x, x, null, null, null, x, null},	
				{x, null, null, x, null, x, null, null, null, x},	
				{null, null, x, null, x, x, null, null, null, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{null, x, x, x, null, null, x, x, x, null},	
				{x, null, x, null, x, null, x, null, null, null},	
				{null, x, null, null, x, x, x, null, null, x},	
				{null, x, null, x, null, null, x, null, x, x},	
				{null, null, null, null, x, x, null, x, null, null},	
				{x, x, x, null, x, null, x, null, x, x},	
				{null, x, x, x, null, x, x, null, x, null},	
				{null, null, null, null, x, x, null, null, null, null},	
				{x, x, x, null, null, x, x, x, x, null},	
				{null, null, x, null, null, null, null, null, null, null},	
				{x, null, null, null, x, x, x, x, x, null},	
				{null, x, null, null, null, null, null, x, x, null},	
				{x, x, x, x, null, null, x, null, x, null},	
				{null, null, null, null, x, x, x, x, null, null},	
				{null, null, null, x, x, null, null, x, null, null},	
				{x, x, null, null, x, x, x, x, x, x},	};
			
			TileType[][] result_1fe = {		
					{x, x, x, x, x, x, x, x, x, x},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	};
				TileType[][] result_1fa = {		
					{x, x, x, x, x, x, x, x, x, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{x, x, x, null, null, x, x, x, x, null},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	
					{x, null, null, x, x, x, null, null, x, x},	};
				TileType[][] result_1me = {		
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	};
				TileType[][] result_1ma = {		
					{null, null, x, null, x, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	
					{x, null, null, x, x, x, null, null, x, x},	};
				TileType[][] result_1le = {		
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	};
				TileType[][] result_1la = {		
					{null, null, x, null, x, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{x, x, x, null, null, x, x, x, x, null},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	};
				TileType[][] result_0fe = {		
					{x, x, null, null, x, x, x, x, x, x},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	};
				TileType[][] result_0fa = {		
					{x, x, null, null, x, x, x, x, x, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{x, x, x, null, null, x, x, x, x, null},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	
					{x, null, null, x, x, x, null, null, x, x},	};
				TileType[][] result_0me = {		
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{x, x, null, null, x, x, x, x, x, x},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	};
				TileType[][] result_0ma = {		
					{null, null, x, null, x, x, null, null, null, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{x, x, null, null, x, x, x, x, x, x},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	
					{x, null, null, x, x, x, null, null, x, x},	};
				TileType[][] result_0le = {		
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{null, null, null, null, null, null, null, null, null, null},	
					{x, x, null, null, x, x, x, x, x, x},	};
				TileType[][] result_0la = {		
					{null, null, x, null, x, x, null, null, null, x},	
					{null, x, null, null, x, null, null, null, null, null},	
					{null, x, null, x, x, null, null, null, x, null},	
					{x, null, null, x, null, x, null, null, null, x},	
					{null, null, x, null, x, x, null, null, null, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{null, x, x, x, null, null, x, x, x, null},	
					{x, null, x, null, x, null, x, null, null, null},	
					{null, x, null, null, x, x, x, null, null, x},	
					{null, x, null, x, null, null, x, null, x, x},	
					{null, null, null, null, x, x, null, x, null, null},	
					{x, x, x, null, x, null, x, null, x, x},	
					{null, x, x, x, null, x, x, null, x, null},	
					{null, null, null, null, x, x, null, null, null, null},	
					{x, x, x, null, null, x, x, x, x, null},	
					{null, null, x, null, null, null, null, null, null, null},	
					{x, null, null, null, x, x, x, x, x, null},	
					{null, x, null, null, null, null, null, x, x, null},	
					{x, x, x, x, null, null, x, null, x, null},	
					{null, null, null, null, x, x, x, x, null, null},	
					{null, null, null, x, x, null, null, x, null, null},	
					{x, x, null, null, x, x, x, x, x, x},	};
					
		boardPanel.tiles = test_1fe;
		assertTrue(boardPanel.checkLine(f));
		assertArrayEquals(result_1fe, boardPanel.tiles);
		
		boardPanel.tiles = test_1fa;
		assertTrue(boardPanel.checkLine(f));
		assertArrayEquals(result_1fa, boardPanel.tiles);
		
		boardPanel.tiles = test_1me;
		assertTrue(boardPanel.checkLine(m));
		assertArrayEquals(result_1me, boardPanel.tiles);
		
		boardPanel.tiles = test_1ma;
		assertTrue(boardPanel.checkLine(m));
		assertArrayEquals(result_1ma, boardPanel.tiles);
		
		boardPanel.tiles = test_1le;
		assertTrue(boardPanel.checkLine(l));
		assertArrayEquals(result_1le, boardPanel.tiles);
		
		boardPanel.tiles = test_1la;
		assertTrue(boardPanel.checkLine(l));
		assertArrayEquals(result_1la, boardPanel.tiles);
		
		boardPanel.tiles = test_0fe;
//		assertFalse(boardPanel.checkLine(f));
//		assertArrayEquals(result_0fe, boardPanel.tiles);
//		
//		boardPanel.tiles = test_0fa;
//		assertFalse(boardPanel.checkLine(f));
//		assertArrayEquals(result_0fa, boardPanel.tiles);
//		
//		boardPanel.tiles = test_0me;
//		assertFalse(boardPanel.checkLine(m));
//		assertArrayEquals(result_0me, boardPanel.tiles);
//		
//		boardPanel.tiles = test_0ma;
//		assertFalse(boardPanel.checkLine(m));
//		assertArrayEquals(result_0ma, boardPanel.tiles);
//		
//		boardPanel.tiles = test_0le;
//		assertFalse(boardPanel.checkLine(l));
//		assertArrayEquals(result_0le, boardPanel.tiles);
//		
//		boardPanel.tiles = test_0la;
//		assertFalse(boardPanel.checkLine(l));
//		assertArrayEquals(result_0la, boardPanel.tiles);	
	}
	
	@Test
	public void testIsOccupied() {
		
		TileType[][] internalState = new TileType[22][10];
		int x = 4;
		int y = 9;
		
		internalState[y][x] = TileType.TypeT;
		boardPanel.tiles = internalState;
		
		int notX = 2;
		int notY = 15;
		
		assertFalse(boardPanel.isOccupied(notX, notY));
		assertFalse(boardPanel.isOccupied(notX, y));
		assertFalse(boardPanel.isOccupied(x, notY));
		assertTrue(boardPanel.isOccupied(x, y));
		
	}
	
	@Test
	public void testSetTile() {
//		boardPanel = new BoardPanel(null);
		TileType[][] expected = new TileType[22][10];
		int x = 4;
		int y = 9;
		TileType testTile = TileType.TypeT;
		
		expected[y][x] = testTile;
		
		boardPanel.setTile(x, y, testTile);
		assertArrayEquals(expected, boardPanel.tiles);
	}
	
	@Test
	public void testGetTile() {
//		boardPanel = new BoardPanel(null);
		TileType[][] expected = new TileType[22][10];
		
		int x = 4;
		int y = 9;
		TileType testTile = TileType.TypeT;
		
		expected[y][x] = testTile;
		
		boardPanel.tiles = expected;
		
		assertEquals(testTile, boardPanel.getTile(x, y));
	}
	
	@Test
	public void testPaintComponentGraphics() {
		Tetris t = null;
		try {
			t = new Tetris();
			t.setVisible(false);
			t.isPaused = true;
			t.currentType = TileType.TypeZ;
			t.currentCol = 2;
			t.currentRow = 0;
		}catch(java.lang.NullPointerException e) {}
	
		boardPanel = new BoardPanel(t);
		
		JFrame frame = new JFrame();
		frame.add(boardPanel);
		frame.setFocusable(true);
		frame.setAlwaysOnTop(true);
		frame.setFocusableWindowState(true);
		frame.pack();
		frame.setVisible(false);
		
	}
	
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/

}
