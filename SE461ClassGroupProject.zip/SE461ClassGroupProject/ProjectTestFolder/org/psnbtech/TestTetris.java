package org.psnbtech;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.awt.Robot; //for the player to not control the game

import org.psnbtech.*;
import java.awt.event.KeyEvent;

public class TestTetris {

//	private Robot tetrisPlayingRobot;
	private Tetris gameTetris;
	
	@Before
	public void setUp() throws Exception{
		//Robot tetrisPlayingRobot = new Robot();
		//gameTetris = new Tetris();
	}
	
	@After
	public void tearDown() throws Exception{
//		tetris = null;
		//tetrisPlayingRobot = null;
	}
	
	@Test
	public void testStartGame() {
		Thread t = new Thread(new Runnable() {
//			@Override
			public void run() {
				try {
					Robot tetrisPlayingRobot = new Robot();
					
					//starts new game
					assertTrue(gameTetris.isNewGame);
					
					//allow the robot to react for a second and proceed to enter the game
					tetrisPlayingRobot.delay(1000);
					tetrisPlayingRobot.keyPress(KeyEvent.VK_ENTER);
					tetrisPlayingRobot.delay(10);
					tetrisPlayingRobot.keyRelease(KeyEvent.VK_ENTER);
					tetrisPlayingRobot.delay(200);
					
					tetrisPlayingRobot.delay(1200);
					
					//set an array of keys that will be interacted in tetris
					int[] press_key = {
							KeyEvent.VK_Q,
							KeyEvent.VK_E,
							KeyEvent.VK_A,
							KeyEvent.VK_A, 	
							KeyEvent.VK_S, 	
							KeyEvent.VK_D, 	
							KeyEvent.VK_D, 	
							
							KeyEvent.VK_K, 
							KeyEvent.VK_Z, 
							KeyEvent.VK_6, 
							KeyEvent.VK_W, 
							
					};
					
					while(!gameTetris.isGameOver) {
						//choose a random key to hit
						int key = press_key[(int)(Math.random() * 100) % 11];
					
						//initialize the directions of the blocks to be used below
						int column = gameTetris.currentCol;
						int rotation = gameTetris.currentRotation;
						int row = gameTetris.currentRow;
//						float millis = tetris.logicTimer.millisPerCycle;
						TileType tile = gameTetris.currentType;
						
						//-- break --\\
						
						tetrisPlayingRobot.delay((int)(Math.random() * 1000) + 200); //delay to press key
						tetrisPlayingRobot.keyPress(key); //presses key
						tetrisPlayingRobot.delay((int)(Math.random() * 500) + 100); //delay to release key
						tetrisPlayingRobot.keyRelease(key); //releases key
						tetrisPlayingRobot.delay(175); //delay before test
						
						//-- break --\\
						
						if(tile == gameTetris.currentType && row < gameTetris.currentRow) {
							switch(key) {
								//Rotate anticlockwise -- counterclockwise
								case KeyEvent.VK_Q:
									assertEquals((rotation == 0 ? 3: (rotation -1%4)), gameTetris.currentRotation);
									break;
								//Rotate clockwise
								case KeyEvent.VK_E:
									assertEquals((rotation++) % 4, gameTetris.currentRotation);
									break;
								//Move left
								case KeyEvent.VK_A:
									assertTrue(gameTetris.currentCol <= column);
									break;
								//Move right
								case KeyEvent.VK_D:
									assertTrue(gameTetris.currentCol >= column);
									break;
								//miscellaneous keys that aren't significant towars the game
								default:
									assertEquals(column, gameTetris.currentCol);
									assertEquals(rotation, gameTetris.currentRotation);
									assertTrue(gameTetris.currentRow > row);
							}
						}
						
						// we want the robot to close the application itself!!
						if(gameTetris.isGameOver) {
							tetrisPlayingRobot.keyPress(KeyEvent.VK_ALT);
							tetrisPlayingRobot.keyPress(KeyEvent.VK_F4);
							tetrisPlayingRobot.keyPress(KeyEvent.VK_ALT);
							tetrisPlayingRobot.keyPress(KeyEvent.VK_F4);
						}
					}
					
//					rob.delay(200);
//					assertTrue(tetris.isGameOver);
//	
//					tetris.dispose();
				
			}catch(Exception a) {
//				fail("start game has an error");
				a.printStackTrace();
			};
		}
			
		});
		gameTetris = new Tetris();
		gameTetris.requestFocus();
		t.start();
		gameTetris.startGame();
	}
	
}