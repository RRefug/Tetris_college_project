package org.psnbtech;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestBoardPanel.class, TestClock.class, TestTetris.class })
public class AllTests {

}
