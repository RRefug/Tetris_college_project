package org.psnbtech;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.psnbtech.*;

import java.awt.Color;
import java.awt.Dimension;
//import java.awt.Font;
//import java.awt.Graphics;

public class TestSidePanel {

//	private SidePanel side;
//	
//	@Before
//	void setUp() throws Exception {
//		side = new SidePanel(null);
//	}
//
//	@After
//	void tearDown() throws Exception {
//		side = null;
//	}

//	@Test
//	public void free() {
//		
//	}
//	@Test
//	public void testSidePanel() {
//		Dimension expected = new Dimension(200, 490);
//		Tetris t = null;
//		
//		try {
//			t = new Tetris();
//			t.isGameOver = true;
//			t.setVisible(false);
//		}catch(java.lang.NullPointerException e) {}
//		
//		side = new SidePanel(t);
//		
//		JFrame frame = new JFrame();
//		frame.add(side);
//		frame.pack();
//		frame.setVisible(true);
//		
//		assertEquals(expected, side.getSize());
//		
//		Color expectedColor = Color.BLACK;
//		assertEquals(expectedColor, side.getBackground());
//		
//		assertEquals(t, side.tetris);
//		frame.dispose();
//		
//	}
//	
//	@Test
//	public void testPaintComponentGraphics() {
//		Tetris t = null;
//		
//		try {
//			t = new Tetris();
//			t.isGameOver = true;
//			t.setVisible(false);
//			
//			t.isPaused = false;
//			t.isGameOver = false;
//		}catch(java.lang.NullPointerException e) {}
//		
//		side = new SidePanel(t);
//		
//		JFrame frame = new JFrame();
//		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//		frame.add(side);
//		frame.setFocusable(true);
//		frame.setAlwaysOnTop(true);
//		frame.setFocusableWindowState(true);
//		frame.pack();
//		frame.setVisible(true);
//		
//		TileType[] expectedTile = {TileType.TypeO, TileType.TypeS, null};
//		int[] expectedLevel = {5, 0, -2};
//		int[] expectedScore = {123, -321, 0};
//		
//		for(int i = 0; i < 3; i++) {
//			t.nextType = expectedTile[i];
//			t.level = expectedLevel[i];
//			t.score = expectedScore[i];
//			
//			side.repaint();
//			frame.requestFocusInWindow();
//			frame.requestFocus();
//			
//		}
//		frame.dispose();		
//	}
	
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}

}
